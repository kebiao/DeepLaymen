import torchvision
import torchvision.transforms as transforms
import matplotlib.pyplot as plt
import numpy as np
import PIL
from PIL import Image
import time
import torch

device = torch.device("cuda:0")

model= torchvision.models.detection.maskrcnn_resnet50_fpn(pretrained=True)
model.to(device)

model.eval()

image = PIL.Image.open('test.jpg')
image_tensor = torchvision.transforms.functional.to_tensor(image)

#torch.cuda.synchronize()

start = time.time()
print("begin")
output = model([image_tensor.to(device)])
#torch.cuda.synchronize()
print("end")
end = time.time()
print("cost==>%ss" % (end - start))
print(len(output)) # it will give a output of list of dictionary
#https://pytorch.org/hub/pytorch_vision_deeplabv3_resnet101/
for i in range(len(output[0]["masks"])):

    # 只有分数大于一定阀值我们才认为是合理的输出
    if output[0]["scores"][i] < 0.7:
        continue
    img = output[0]["masks"]
    img = img.data.cpu().numpy()[i]
    

    img = np.transpose(img, (1, 2, 0)).reshape(image.height, image.width)
    plt.imsave('result/maskrcnn_%d.jpg' %i, img)